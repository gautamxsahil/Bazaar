/**
 * Minimal Marketplace Server
 * Features:
 * - Static frontend (public/)
 * - In-memory products, users, orders (reset on restart)
 * - Simple auth via demo tokens (NOT production ready)
 * - CRUD: list/create products; place order
 */
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- In-memory stores ---
let products = [
  { id: 'p1', title: 'Wireless Earbuds', price: 1499, image: 'https://picsum.photos/seed/ear/400/300', sellerId: 's1', stock: 25, description: 'BT 5.3, 24h playtime.' },
  { id: 'p2', title: 'Phone Case', price: 299, image: 'https://picsum.photos/seed/case/400/300', sellerId: 's2', stock: 120, description: 'Shock‑absorbent TPU, matte.' },
  { id: 'p3', title: 'Smartwatch', price: 2499, image: 'https://picsum.photos/seed/watch/400/300', sellerId: 's1', stock: 10, description: 'SpO2, HR, GPS.' }
];
let users = [
  { id: 'buyer1', role: 'buyer', email: 'buyer@example.com', password: 'buyer123', name: 'Demo Buyer' },
  { id: 'seller1', role: 'seller', email: 'seller@example.com', password: 'seller123', name: 'Demo Seller' },
  { id: 'admin1', role: 'admin', email: 'admin@example.com', password: 'admin123', name: 'Site Admin' },
];
let sessions = {}; // token -> userId
let orders = [];

// --- Helpers ---
const makeId = () => Math.random().toString(36).slice(2, 10);
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token || !sessions[token]) return res.status(401).json({ error: 'Unauthorized' });
  req.user = users.find(u => u.id === sessions[token]);
  next();
}

// --- Auth ---
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const token = makeId();
  sessions[token] = user.id;
  res.json({ token, user: { id: user.id, role: user.role, name: user.name, email: user.email } });
});
app.get('/api/me', authMiddleware, (req, res) => {
  const { id, role, name, email } = req.user;
  res.json({ id, role, name, email });
});

// --- Products ---
app.get('/api/products', (req, res) => {
  res.json(products);
});
app.get('/api/products/:id', (req, res) => {
  const p = products.find(pr => pr.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});
app.post('/api/products', authMiddleware, (req, res) => {
  if (req.user.role !== 'seller' && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only sellers/admin can add products' });
  }
  const { title, price, image, stock, description } = req.body;
  if (!title || !price) return res.status(400).json({ error: 'title and price required' });
  const newP = { id: makeId(), title, price: Number(price), image: image || 'https://picsum.photos/seed/' + makeId() + '/400/300', sellerId: req.user.id, stock: Number(stock ?? 0), description: description || '' };
  products.push(newP);
  res.status(201).json(newP);
});

// --- Orders ---
app.post('/api/orders', authMiddleware, (req, res) => {
  if (req.user.role !== 'buyer' && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only buyers/admin can place orders' });
  }
  const { items } = req.body; // [{productId, qty}]
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'items required' });
  // stock check (simplified)
  for (const it of items) {
    const prod = products.find(p => p.id === it.productId);
    if (!prod) return res.status(400).json({ error: 'Product not found: ' + it.productId });
    if (prod.stock < it.qty) return res.status(400).json({ error: `Insufficient stock for ${prod.title}` });
  }
  // deduct
  items.forEach(it => {
    const prod = products.find(p => p.id === it.productId);
    prod.stock -= it.qty;
  });
  const order = { id: makeId(), userId: req.user.id, items, createdAt: new Date().toISOString(), status: 'PLACED' };
  orders.push(order);
  res.status(201).json(order);
});

// --- Admin (simple list) ---
app.get('/api/orders', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admins only' });
  res.json(orders);
});

// Fallback to index.html for root
app.get('/health', (_, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log('Marketplace server running on http://localhost:' + PORT);
});

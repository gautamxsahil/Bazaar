// --- Simple client-side utilities ---
const $ = (sel, el=document) => el.querySelector(sel);
const $$ = (sel, el=document) => Array.from(el.querySelectorAll(sel));
const API = {
  async login(email, password){
    const r = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email, password}) });
    if(!r.ok) throw new Error((await r.json()).error || 'Login failed');
    return r.json();
  },
  async me(){
    const token = localStorage.getItem('token');
    const r = await fetch('/api/me', { headers: { Authorization: 'Bearer ' + token } });
    if(!r.ok) throw new Error('Not logged in');
    return r.json();
  },
  async products(){
    const r = await fetch('/api/products'); return r.json();
  },
  async product(id){
    const r = await fetch('/api/products/' + id); return r.json();
  },
  async addProduct(data){
    const token = localStorage.getItem('token');
    const r = await fetch('/api/products', { method:'POST', headers:{ 'Content-Type':'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(data) });
    if(!r.ok) throw new Error((await r.json()).error || 'Add failed');
    return r.json();
  },
  async order(items){
    const token = localStorage.getItem('token');
    const r = await fetch('/api/orders', { method:'POST', headers:{ 'Content-Type':'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({items}) });
    if(!r.ok) throw new Error((await r.json()).error || 'Order failed');
    return r.json();
  },
  async orders(){
    const token = localStorage.getItem('token');
    const r = await fetch('/api/orders', { headers: { Authorization: 'Bearer ' + token } });
    if(!r.ok) throw new Error((await r.json()).error || 'Cannot load orders');
    return r.json();
  }
};

// --- Auth helpers ---
function setAuth(token, user){
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
}
function getUser(){
  const u = localStorage.getItem('user');
  return u ? JSON.parse(u) : null;
}
function logout(){
  localStorage.removeItem('token'); localStorage.removeItem('user'); location.href = '/';
}
async function requireAuth(role){
  try{
    const me = await API.me();
    if(role && me.role !== role){ alert('Forbidden: need ' + role); location.href = '/login.html'; }
  }catch(err){
    alert('Please login first'); location.href = '/login.html';
  }
}

// --- Cart (localStorage) ---
function getCart(){
  return JSON.parse(localStorage.getItem('cart') || '[]');
}
function setCart(cart){
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartLink();
}
function addToCart(productId, qty=1){
  const cart = getCart();
  const existing = cart.find(i => i.productId === productId);
  if(existing) existing.qty += qty; else cart.push({ productId, qty });
  setCart(cart);
  alert('Added to cart');
}
function updateCartLink(){
  const cart = getCart();
  const count = cart.reduce((a,c)=>a+c.qty,0);
  const link = $('#cartLink');
  if(link) link.textContent = 'Cart (' + count + ')';
}

// --- UI renderers ---
async function loadProducts(cb){
  const data = await API.products();
  const grid = $('#productGrid');
  if(grid){
    grid.innerHTML = data.map(p => `
      <article class="card">
        <img src="${p.image}" alt="${p.title}"/>
        <div class="p">
          <h3>${p.title}</h3>
          <div class="price">₹${p.price}</div>
        </div>
        <div class="p">
          <a class="btn" href="/product.html?id=${p.id}">View</a>
          <button class="btn primary" onclick="addToCart('${p.id}', 1)">Add to Cart</button>
        </div>
      </article>
    `).join('');
  }
  cb && cb();
}

function renderSellerProducts(){
  const grid = $('#sellerProducts');
  if(!grid) return;
  API.products().then(list => {
    grid.innerHTML = list.map(p => `
      <article class="card">
        <img src="${p.image}" alt="${p.title}"/>
        <div class="p">
          <h3>${p.title}</h3>
          <div class="price">₹${p.price}</div>
          <div class="small">Stock: ${p.stock}</div>
        </div>
      </article>
    `).join('');
  });
}

function getQueryParam(name){
  const url = new URL(window.location.href);
  return url.searchParams.get(name);
}

async function renderProductDetail(){
  const id = getQueryParam('id');
  const p = await API.product(id);
  const el = $('#productDetail');
  el.innerHTML = `
    <div class="product-detail">
      <div><img src="${p.image}" alt="${p.title}"/></div>
      <div>
        <h2>${p.title}</h2>
        <div class="price">₹${p.price}</div>
        <p>${p.description || ''}</p>
        <div class="kv"><div>Stock</div><div>${p.stock}</div></div>
        <div style="margin-top:16px;">
          <button class="btn primary" onclick="addToCart('${p.id}', 1)">Add to Cart</button>
          <button class="btn" onclick="checkoutNow('${p.id}')">Buy Now</button>
        </div>
      </div>
    </div>
  `;
}

async function checkoutNow(productId){
  const user = getUser();
  if(!user){ alert('Please login as buyer to checkout'); location.href = '/login.html'; return; }
  const role = user.role;
  if(role !== 'buyer' && role !== 'admin'){ alert('Only buyers can checkout in demo'); return; }
  try{
    const order = await API.order([{ productId, qty: 1 }]);
    alert('Order placed: ' + order.id);
    setCart([]);
    location.href = '/';
  }catch(e){
    alert(e.message);
  }
}

// --- Forms ---
function bindLogin(){
  const form = $('#loginForm');
  form?.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const fd = new FormData(form);
    try{
      const { token, user } = await API.login(fd.get('email'), fd.get('password'));
      setAuth(token, user);
      alert('Welcome, ' + user.name);
      location.href = '/';
    }catch(err){ alert(err.message); }
  });
}

function bindAddProduct(){
  const form = $('#addProductForm');
  form?.addEventListener('submit', async (e)=>{
    e.preventDefault();
    try{
      const fd = new FormData(form);
      const data = Object.fromEntries(fd.entries());
      const p = await API.addProduct(data);
      alert('Added: ' + p.title);
      form.reset();
      renderSellerProducts();
    }catch(err){ alert(err.message); }
  });
}
